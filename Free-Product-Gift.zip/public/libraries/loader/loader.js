jQuery(document).ready(function () {

    jQuery("body").append('<div id="loader-background" style="display:none">' +
        '<div id="background_container">' +
        '<lottie-player src="https://assets9.lottiefiles.com/packages/lf20_b88nh30c.json" background="transparent" speed="1" style="width: 100%; height: 100%;" loop autoplay></lottie-player>' +
        '</div>' +
        '</div>');

});